package Model;

import org.bson.types.ObjectId;

import java.text.DecimalFormat;
import java.util.Objects;

public class Carro {
    
    private ObjectId id;
    private String modelo;
    private String cor;
    private Double valor;
    private Integer ano;
    private String nomeMarca;
    private String placa;

    public Carro() {

    }

    public Carro( String modelo, String cor, Double valor, Integer ano, String nomeMarca, String placa) {
        this.modelo = modelo;
        this.cor = cor;
        this.valor = valor;
        this.ano = ano;
        this.nomeMarca = nomeMarca;
        this.placa = placa;
    }

    public ObjectId getId() {
        return this.id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getModelo() {
        return this.modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCor() {
        return this.cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public Double getValor() {
        return this.valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Integer getAno() {
        return this.ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public String getNomeMarca() {
        return this.nomeMarca;
    }

    public void setNomeMarca(String nomeMarca) {
        this.nomeMarca = nomeMarca;
    }

    public String getPlaca() {
        return this.placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public Carro id(ObjectId id) {
        setId(id);
        return this;
    }

    public Carro modelo(String modelo) {
        setModelo(modelo);
        return this;
    }

    public Carro cor(String cor) {
        setCor(cor);
        return this;
    }

    public Carro valor(Double valor) {
        setValor(valor);
        return this;
    }

    public Carro ano(Integer ano) {
        setAno(ano);
        return this;
    }

    public Carro nomeMarca(String nomeMarca) {
        setNomeMarca(nomeMarca);
        return this;
    }

    public Carro placa(String placa) {
        setPlaca(placa);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Carro)) {
            return false;
        }
        Carro carro = (Carro) o;
        return Objects.equals(id, carro.id) && Objects.equals(modelo, carro.modelo) && Objects.equals(cor, carro.cor) && Objects.equals(valor, carro.valor) && Objects.equals(ano, carro.ano) && Objects.equals(nomeMarca, carro.nomeMarca) && Objects.equals(placa, carro.placa);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, modelo, cor, valor, ano, nomeMarca, placa);
    }
    
    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("#,###.000"); 
        return  "   "+getModelo()+"\n"+
             "     "+getCor()+"\n"+ 
             "         "+getNomeMarca()+"\n"+
             "             "+getAno()+"\n"+
             "                Placa: "+getPlaca()+"\n"+
             "                     R$: "+df.format(+getValor())+"\n";
    }
    
}

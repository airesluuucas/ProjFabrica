package Model;

import java.util.Comparator;

public class NomeComparator implements Comparator<Marca>{

    @Override
    public int compare(Marca m1, Marca m2) {

        String nomeMarca1 = m1.getNome();
        String nomeMarca2 = m2.getNome();
        return nomeMarca1.compareTo(nomeMarca2);
    }
    
}

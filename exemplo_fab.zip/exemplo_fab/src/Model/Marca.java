package Model;
import java.text.DecimalFormat;
import org.bson.types.ObjectId;

public class Marca {
    
    private ObjectId id;
    private String nome;
    private String sede;
    private Double valor; 

    public Marca(String nome, String sede, Double valor) {
        this.nome = nome;
        this.sede = sede;
        this.valor = valor;
    }

    public Marca(){
        
    }
    public ObjectId getId() {
        return this.id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSede() {
        return this.sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }

    public Double getValor() {
        return this.valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("##,###.000"); 
        return
            "    " + getNome() + "\n" +
            "      " + getSede() + "\n" +
            "        R$: " + df.format(getValor());
    }

}

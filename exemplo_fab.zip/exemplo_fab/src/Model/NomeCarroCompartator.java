package Model;

import java.util.Comparator;

public class NomeCarroCompartator implements Comparator<Carro>{
    
    @Override
    public int compare(Carro c1, Carro c2) {

        String nomecarro1 = c1.getModelo();
        final String nomecarro2 = c2.getModelo();
        return nomecarro1.compareTo(nomecarro2);
    }
}

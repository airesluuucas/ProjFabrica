package Controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MenuCarroController {

    @FXML
    private Button sair;

    @FXML
    void opAlterar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaAlterarCarro");
        
    }

    @FXML
    void opBuscar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaBuscarCarro");
        
    }

    @FXML
    void opExcluir(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaApagarCarro");

    }

    @FXML
    void opInserir(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaInserirCarro");
        
    }

    @FXML
    void opListar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaListarCarro");

    }

    @FXML
    void opSair(ActionEvent event) {

        Stage janela = (Stage)sair.getScene().getWindow();
        janela.close();

    }

    @FXML
    void opVoltar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaMenuPrincipal");
        
    }

}
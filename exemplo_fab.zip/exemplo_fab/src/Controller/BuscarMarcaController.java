package Controller;

import java.io.IOException;
import java.text.DecimalFormat;

import org.controlsfx.control.Notifications;

import Model.Marca;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class BuscarMarcaController {

    @FXML
    private Button buscar;

    @FXML
    private TextField nomeBuscarMarca;

    @FXML
    private TextField nomeMarca;

    @FXML
    private TextField sedeMarca;

    @FXML
    private TextField valorMarca;

    @FXML
    private Button voltar;

    final DecimalFormat df = new DecimalFormat("##,###.00");

    @FXML
    void opBuscar(ActionEvent event) throws IOException {

        final Marca m;
        final MarcaController mc = new MarcaController();

        m = mc.buscar(nomeBuscarMarca.getText().toUpperCase());

        if(m != null){

            nomeMarca.setText(m.getNome());
            sedeMarca.setText(m.getSede());
            valorMarca.setText(String.valueOf(df.format(m.getValor())));

        }else{

            Notifications.create()
                .position(Pos.CENTER)
                .title("...")
                .text("Não existe nenhum marca cadastrada!!!")
                .showInformation();
            
        }

    }

    @FXML
    void opVoltar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaMenuMarca");
        
    }

}
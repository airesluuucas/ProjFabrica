package Controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MenuPrincipalController {

    @FXML
    private Button sair;

    @FXML
    void opCarro(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaMenuCarro");

    }

    @FXML
    private void opMarca() throws IOException {
        App.setRoot("/View/TelaMenuMarca");
    }

    @FXML
    void opSair(ActionEvent event) {

        Stage janela = (Stage) sair.getScene().getWindow();
        janela.close();
        
    }

}
package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.ResourceBundle;
import org.controlsfx.control.Notifications;
import Model.Carro;
import Model.Marca;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class InserirCarroController implements Initializable{

    @FXML
    private TextField ano;

    @FXML
    private TextField cor;

    @FXML
    private Button inserir;

    @FXML
    private ComboBox<String> marca;

    @FXML
    private TextField modelo;

    @FXML
    private TextField placa;

    @FXML
    private Button sair;

    @FXML
    private TextField valor;

    @FXML
    private Button voltar;
    private ObservableList<String> teste = FXCollections.observableArrayList();
    private ArrayList<Marca> a;

    @FXML
    void opSair(ActionEvent event) {

        Stage janela = (Stage) sair.getScene().getWindow();
        janela.close();

    }

    @FXML
    void opInserir(ActionEvent event) throws IOException {

        try {
            
                final Calendar cal = Calendar.getInstance();
                final int year = cal.get(Calendar.YEAR);

                if((marca.getSelectionModel().isSelected(marca.getSelectionModel().getSelectedIndex())) && Integer.parseInt(ano.getText()) <= year  && Integer.parseInt(ano.getText()) >= 1886){
                    String retMarca = marca.getItems().get(marca.getSelectionModel().getSelectedIndex());

                    Carro carro = new Carro();
                    CarroController c = new CarroController();
                    
                    carro.setModelo(modelo.getText().toUpperCase());
                    carro.setCor(cor.getText().toUpperCase());
                    carro.valor(Double.parseDouble(valor.getText().replace("," , ".")));
                    carro.setAno(Integer.parseInt(ano.getText()));
                    carro.setPlaca(placa.getText().toUpperCase());
                    carro.setNomeMarca(retMarca);

                    c.inserirCarro(carro);
                        Notifications.create()
                            .position(Pos.CENTER)
                            .title("Boa...")
                            .text("Sucesso ao inserir.... Carro cadastrado com sucesso!!!")
                            .showInformation();

                    App.setRoot("/View/TelaMenuCarro");

                }else{

                    Notifications.create()
                        .position(Pos.CENTER)
                        .title("Erro...")
                        .text("Erro ao inserir.... Já existe esse carro cadastrado!!!")
                        .showInformation();

                }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        
        marca.setPromptText("Selecione...");
        final MarcaController c = new MarcaController();
        a = c.listar();
    
        if(a != null){

            for (Marca maaa : a) {
            
                teste.add(maaa.getNome());

            }
            
            marca.setItems(teste);

        }else{

            Notifications.create()
            .position(Pos.CENTER)
            .title("...")
            .text("Não existe nenhuma marca cadastrada!!!")
            .showInformation();

        }

    }
    
    @FXML
    void opVoltar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaMenuCarro");

    }

}
package Controller;

import java.util.ArrayList;
import org.bson.Document;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import Model.Marca;
import Model.NomeComparator;

public class MarcaController {
    
    private MongoCollection<Marca> _m;

    public MarcaController(){

        _m = Connection.getDatabase().getCollection("Marca", Marca.class);

    }

    public void inserirMarca(Marca marca) {

        try {

            _m.insertOne(marca); 

            
        } catch (Exception e) {
           e.printStackTrace();
        }

    }
    
    public boolean repetido(String nomeAux){

        try {
            
            final Marca m = buscar(nomeAux);
            if(m == null){

                return false;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return true;

    }

    public ArrayList<Marca> listar(){

        try {

            final ArrayList<Marca> list = new ArrayList<>();
            final MongoCollection<Document> d = Connection.getDatabase().getCollection("Marca");
            final FindIterable<Document> r = d.find().sort(null);
            final MongoCursor<Document> cursor = r.iterator();
            Document document = new Document();

            while (cursor.hasNext()) {

                Marca m = new Marca();
                document = cursor.next();
                m.setId(document.getObjectId("_id"));
                m.setNome(document.getString("nome"));
                m.setSede(document.getString("sede"));
                m.setValor(document.getDouble("valor"));
                list.add(m);

            }

            list.sort(new NomeComparator());
            return list;

        } catch (Exception e) {

           e.printStackTrace();
           
        }

        return null;

    }

    public Marca buscar(String nome){
        
        try {
         
          final Document query = new Document("nome", nome);
          final Marca marca = _m.find(query).first();
          return marca;
          
        } catch (Exception e) {
           e.printStackTrace();
           return null;
        }
        
    }

    public void apagar(String nome){

        try {
         
          final Document query = new Document("nome", nome);
          _m.deleteOne(query);
          
        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    public void alterar(Marca m, String nomeAnt){

        try {

          final Document updateQuery = new Document("nome", nomeAnt);
          final Document update = new Document("$set", m);
          _m.updateMany(updateQuery, update);

        } catch (Exception e) {

            e.printStackTrace();
            
        }

    }

}
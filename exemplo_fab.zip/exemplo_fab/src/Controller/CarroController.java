package Controller;

import java.util.ArrayList;
import org.bson.Document;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import Model.Carro;
import Model.NomeCarroCompartator;

public class CarroController {
    
    private MongoCollection<Carro> _m;

    public CarroController(){

        _m = Connection.getDatabase().getCollection("Carro", Carro.class);

    }

    public void inserirCarro(Carro carro) {

        try {

            _m.insertOne(carro); 

        } catch (Exception e) {
           e.printStackTrace();
        }

    }   

    public ArrayList<Carro> listarCarro(){

       try {

            final ArrayList<Carro> list = new ArrayList<>();
            final MongoCollection<Document> d = Connection.getDatabase().getCollection("Carro");
            final FindIterable<Document> r = d.find();
            final MongoCursor<Document> cursor = r.iterator();

            Document document = new Document();

            while (cursor.hasNext()) {

                Carro c = new Carro();
                document = cursor.next();
                c.setId(document.getObjectId("_id"));
                c.setModelo(document.getString("modelo"));
                c.setNomeMarca(document.getString("nomeMarca"));
                c.setCor(document.getString("cor"));
                c.setAno(document.getInteger("ano"));
                c.setValor(document.getDouble("valor"));
                c.setPlaca(document.getString("placa"));

                list.add(c);

            }

            list.sort(new NomeCarroCompartator());
            return list;

        } catch (Exception e) {

           e.printStackTrace();
           
        }
        
        return null;

    }

    public Carro buscar(String nome){

        try {
         
            final Document query = new Document("placa", nome);
            final Carro carro = _m.find(query).first();
            
            return carro;
          
        } catch (Exception e) {

            e.printStackTrace();
                
        }

        return null;
    }

    public void apagar(String nome) {

        try {
         
          final Document query = new Document("placa", nome);
          _m.deleteOne(query);
          
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public Carro buscarPorMarca(String nome){

        Carro car = null;

        try {
         
            final Document query = new Document("nomeMarca", nome);
            car = _m.find(query).first();

            if(car != null){
                System.out.println("11111");
                return car;

            }else{

                return null;
            }
            
        } catch (Exception e) {

            e.printStackTrace();
               
        }
            System.out.println("22222");
        return car;
    }
    
    public void alterar(Carro carro, String nomeAnt){

        try {

          final Document updateQuery = new Document("placa", nomeAnt);
          final Document update = new Document("$set", carro);
          _m.updateMany(updateQuery, update);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
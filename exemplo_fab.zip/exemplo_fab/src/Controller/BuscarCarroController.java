package Controller;

import java.io.IOException;
import java.text.DecimalFormat;

import org.controlsfx.control.Notifications;

import Model.Carro;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class BuscarCarroController {
        
    @FXML
    private TextField ano;

    @FXML
    private Button buscar;

    @FXML
    private TextField cor;

    @FXML
    private TextField marca;

    @FXML
    private TextField modelo;

    @FXML
    private TextField placa;

    @FXML
    private TextField placaBuscarCarro;

    @FXML
    private TextField valor;

    @FXML
    private Button voltar;

    @FXML
    void opBuscar(ActionEvent event) throws IOException {

        final Carro carro;
        final CarroController c = new CarroController();
        final DecimalFormat df = new DecimalFormat("###,###.00");

        carro = c.buscar(placaBuscarCarro.getText().toUpperCase());

        if(carro != null){

            modelo.setText(carro.getModelo());
            cor.setText(carro.getCor());
            marca.setText(carro.getNomeMarca());
            ano.setText(String.valueOf(carro.getAno()));
            valor.setText(String.valueOf(df.format(carro.getValor())));
            placa.setText(carro.getPlaca());

        }else{

            Notifications.create()
                .position(Pos.CENTER)
                .title("...")
                .text("Não existe nenhum carro cadastrado!!!")
                .showInformation();
                
        }

    }

    @FXML
    void opVoltar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaMenuCarro");
        
    }

}
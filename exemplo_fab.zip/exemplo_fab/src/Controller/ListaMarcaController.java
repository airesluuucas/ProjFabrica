package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import org.controlsfx.control.Notifications;

import Model.Marca;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

public class ListaMarcaController implements Initializable{

    @FXML
    private ListView<Marca> listMarca;
    @FXML
    private Button voltar;
    private ObservableList<Marca> listaFinal = FXCollections.observableArrayList();
    private ArrayList<Marca> m;
    
    @FXML
    void opVoltar(ActionEvent event) throws IOException {

       App.setRoot("/View/TelaMenuMarca");

    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {

        final MarcaController c = new MarcaController();
        m = c.listar();
    
        if(m != null){

            for (Marca marca : m) {
            
                listaFinal.add(marca);

            }

            listMarca.setItems(listaFinal);

        }else{

                Notifications.create()
                    .position(Pos.CENTER)
                    .title("...")
                    .text("Não existe nenhum marca cadastrado!!!")
                    .showInformation();

        }

    }

}
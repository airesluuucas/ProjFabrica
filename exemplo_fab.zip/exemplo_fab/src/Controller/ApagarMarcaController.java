package Controller;

import java.io.IOException;
import java.text.DecimalFormat;

import org.controlsfx.control.Notifications;

import Model.Carro;
import Model.Marca;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class ApagarMarcaController {

    private MarcaController mc = new MarcaController();

    @FXML
    private Button excluir;

    @FXML
    private Button buscar;

    @FXML
    private Button voltar;

    @FXML
    private TextField nomeBuscarMarca;

    @FXML
    private TextField nomeMarca;

    @FXML
    private TextField sedeMarca;

    @FXML
    private TextField valorMarca;

    @FXML
    void opExcluir(ActionEvent event) throws IOException {

        try {
            
            CarroController carroController = new CarroController();
            Carro car = carroController.buscarPorMarca(nomeBuscarMarca.getText().toUpperCase());
        
            if(car == null){

                mc.apagar(nomeBuscarMarca.getText().toUpperCase());
                
                Notifications.create()
                    .position(Pos.CENTER)
                    .title("Boa...")
                    .text("Sucesso.... Marca apagado com sucesso!!!")
                    .showInformation();

                App.setRoot("/View/TelaMenuMarca");

            }else{

                Notifications.create()
                    .position(Pos.CENTER)
                    .title("Erro...")
                    .text("Erro ao excluir.... Marca já possui um carro cadastrado!!!")
                    .showInformation();

            }
        } catch (Exception e) {
                e.printStackTrace();
        }
        
    }

    @FXML
    void opBuscar(ActionEvent event) {

        final Marca m;
        
        m = mc.buscar(nomeBuscarMarca.getText().toUpperCase());
        final DecimalFormat df = new DecimalFormat("###,###.00"); 

        nomeMarca.setText(m.getNome().toUpperCase());
        sedeMarca.setText(m.getSede().toUpperCase());
        valorMarca.setText(String.valueOf(df.format(m.getValor())));

    }

    @FXML
    void opVoltar(ActionEvent event) throws IOException {

         App.setRoot("/View/TelaMenuMarca");
         
    }

}
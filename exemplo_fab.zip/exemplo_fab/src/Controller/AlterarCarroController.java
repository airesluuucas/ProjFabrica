package Controller;

import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
//import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Model.Carro;
import Model.Marca;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class AlterarCarroController implements Initializable{

    @FXML
    private Button alterar;

    @FXML
    private TextField ano;

    @FXML
    private Button buscar;

    @FXML
    private TextField cor;

    @FXML
    private ComboBox<String> marca;

    @FXML
    private TextField modelo;

    @FXML
    private TextField valor;

    @FXML
    private TextField placa;

    @FXML
    private TextField buscarPlaca;

    @FXML
    private Button voltar;

    private ObservableList<String> teste = FXCollections.observableArrayList();
    private ArrayList<Marca> a;
    private String nomeAux, nomeAuxMarca;
    private CarroController c = new CarroController();
    final DecimalFormat df = new DecimalFormat("###,###.00");

    private Carro carro = new Carro();

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {

        final MarcaController c = new MarcaController();
        a = c.listar();
    
        if(a != null){

            for (Marca maaa : a) {
            
                teste.add(maaa.getNome());

            }
            marca.setItems(teste);

        }else{

            System.out.println("Erro");

        }

    }

    @FXML
    void btBuscar(ActionEvent event) {

        carro = c.buscar(buscarPlaca.getText().toUpperCase());

        if(carro != null){

            nomeAux = buscarPlaca.getText().toUpperCase();
            modelo.setText(carro.getModelo());
            cor.setText(carro.getCor());
            marca.setPromptText(carro.getNomeMarca());
            nomeAuxMarca = carro.getNomeMarca();
            ano.setText(String.valueOf(carro.getAno()));
            valor.setText(String.valueOf(carro.getValor()));
            placa.setText(carro.getPlaca());

        }else{

            System.out.println("Erro");
            
        }

    }

    @FXML
    void btAlterar(ActionEvent event) throws IOException {

    Integer achou = marca.getSelectionModel().getSelectedIndex();
    
        try {

            //Esse retorno maior ou igual a 0 indica que é a posição
            if(achou >= 0 ){

                String retMarca = marca.getItems().get(marca.getSelectionModel().getSelectedIndex());
        
                carro.setAno(Integer.parseInt(ano.getText()));
                carro.setCor(cor.getText().toUpperCase());
                carro.setModelo(modelo.getText().toUpperCase());
                carro.setNomeMarca(retMarca);
                carro.setValor(Double.parseDouble(valor.getText().replace("," , ".")));
                carro.setPlaca(placa.getText().toUpperCase());


            }else if(achou == -1){

                //Esse retorno igual a -1 é quando não seleciona
                System.out.println("Não entrou");
                carro.setAno(Integer.parseInt(ano.getText()));
                carro.setCor(cor.getText().toUpperCase());
                carro.setModelo(modelo.getText().toUpperCase());
                carro.setValor(Double.parseDouble(valor.getText().replace("," , "."))); 
                carro.setPlaca(placa.getText().toUpperCase());
                carro.setNomeMarca(nomeAuxMarca);   
            
            }

            c.alterar(carro, nomeAux);
            App.setRoot("/View/TelaMenuCarro");

         } catch (Exception e) {
             e.printStackTrace();
        }
    }
    
    @FXML
    void btVoltar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaMenuCarro");

    }
}
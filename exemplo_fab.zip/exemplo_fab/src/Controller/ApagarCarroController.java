package Controller;

import java.io.IOException;
import java.text.DecimalFormat;

import org.controlsfx.control.Notifications;

import Model.Carro;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class ApagarCarroController {

    @FXML
    private TextField ano;

    @FXML
    private Button buscar;

    @FXML
    private TextField cor;

    @FXML
    private Button excluir;

    @FXML
    private TextField marca;

    @FXML
    private TextField modelo;

    @FXML
    private TextField valor;

    @FXML
    private TextField placa;

    @FXML
    private TextField buscaPlaca;

    @FXML
    private Button voltar;

    private CarroController c = new CarroController();

    private Carro carro;

    @FXML
    void btBuscar(ActionEvent event) {

        final DecimalFormat df = new DecimalFormat("###,###.00");

        carro = c.buscar(buscaPlaca.getText().toUpperCase());

        if(carro != null){

            modelo.setText(carro.getModelo());
            cor.setText(carro.getCor());
            marca.setText(carro.getNomeMarca());
            ano.setText(String.valueOf(carro.getAno()));
            valor.setText(String.valueOf(df.format(carro.getValor())));
            placa.setText(carro.getPlaca());

        }else{

                Notifications.create()
                    .position(Pos.CENTER)
                    .title("Erro...")
                    .text("Não possui este carro cadastrado!!!")
                    .showInformation();
            
        }

    }

    @FXML
    void btExcluir(ActionEvent event) {

        try {
            
            c.apagar(carro.getPlaca());
            Notifications.create()
                .position(Pos.CENTER)
                .title("Boa...")
                .text("Carro excluído.... Carro excluido com sucesso!!!")
                .showInformation();

            App.setRoot("/View/TelaMenuCarro");

        } catch (Exception e) {
           
            Notifications.create()
                .position(Pos.CENTER)
                .title("Erro...")
                .text("Erro ao excluir o carro informado, entre me contado com o suporte!!!")
                .showInformation();

        }

    }

    @FXML
    void btVoltar(ActionEvent event) throws IOException{

        App.setRoot("/View/TelaMenuCarro");

    }

}
package Controller;

import java.io.IOException;
import java.text.DecimalFormat;

import Model.Marca;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class AlterarMarcaController {

    @FXML
    private Button alterar;

    @FXML
    private Button buscar;

    @FXML
    private TextField nomeBuscarMarca;

    @FXML
    private TextField nomeMarca;

    @FXML
    private TextField sedeMarca;

    @FXML
    private TextField valorMarca;

    @FXML
    private Button voltar;

    private MarcaController mc = new MarcaController();
    private Marca m;
    private String nomeAux;
    final DecimalFormat df = new DecimalFormat("###,###.00");

    @FXML
    void opAlterar(ActionEvent event) throws IOException {

        m.setNome(nomeMarca.getText().toUpperCase());
        m.setSede(sedeMarca.getText().toUpperCase());
        m.setValor(Double.parseDouble(valorMarca.getText().replace("," , ".")));
        mc.alterar(m, nomeAux);

        App.setRoot("/View/TelaMenuMarca");

    }

    @FXML
    void opBuscar(ActionEvent event) {

        m = mc.buscar(nomeBuscarMarca.getText().toUpperCase());

        nomeAux = m.getNome();
        nomeMarca.setText(m.getNome());
        sedeMarca.setText(m.getSede());
        valorMarca.setText(String.valueOf(m.getValor()));
        
    }

    @FXML
    void opVoltar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaMenuMarca");
        
    }

}
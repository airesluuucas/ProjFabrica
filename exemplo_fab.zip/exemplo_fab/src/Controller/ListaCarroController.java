package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import org.controlsfx.control.Notifications;

import Model.Carro;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

public class ListaCarroController implements Initializable{

    @FXML
    private ListView<Carro> listCarro;
    private ObservableList<Carro> adicionaCarro = FXCollections.observableArrayList();
    private ArrayList<Carro> recebe;
    @FXML
    private Button voltar;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {

        final CarroController c = new CarroController();
        recebe = c.listarCarro();

        if(recebe != null){

            for (Carro carro : recebe) {
            
                adicionaCarro.add(carro);

            }

            listCarro.setItems(adicionaCarro);

        }else{

                Notifications.create()
                    .position(Pos.CENTER)
                    .title("...")
                    .text("Não existe nenhum carro cadastrado!!!")
                    .showInformation();

        }

    }

    @FXML
    void opVoltar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaMenuCarro");
    }

}

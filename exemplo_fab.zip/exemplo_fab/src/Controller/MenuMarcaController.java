package Controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MenuMarcaController {
    
    @FXML
    private Button sair;

    @FXML
    void opAlterar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaAlterarMarca");
        
    }

    @FXML
    void opBuscar(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaBuscarMarca");
        
    }

    @FXML
    void opExcluir(ActionEvent event) throws IOException {

        App.setRoot("/View/TelaApagarMarca");

    }

    @FXML
    void opInserir(ActionEvent event) throws IOException{
    
        App.setRoot("/View/TelaInserirMarca");

    }

    @FXML
    void opListar(ActionEvent event) throws IOException{
        
         App.setRoot("/View/TelaListaMarca");

    }
    
    @FXML
    void opVoltar(ActionEvent event) throws IOException{

        App.setRoot("/View/TelaMenuPrincipal");

    }

    @FXML
    void opSair(ActionEvent event) {

        Stage janela = (Stage) sair.getScene().getWindow();
        janela.close();

    }
    
}
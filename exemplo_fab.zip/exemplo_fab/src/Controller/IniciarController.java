package Controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class IniciarController {
    
    //Botão de iniciar
    @FXML
    private Button iniciar;

    //Botão de sair
    @FXML
    private Button sair;

    //Ação do botão de iniciar
    @FXML
    private void opIniciar() throws IOException {
        App.setRoot("/View/TelaMenuPrincipal");
    }

    //Ação do botão de sair
    @FXML
    void opSair(ActionEvent event) {

        Stage janela = (Stage) sair.getScene().getWindow();
        janela.close();

    }
}

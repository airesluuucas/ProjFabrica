package Controller;

import java.io.IOException;

import org.controlsfx.control.Notifications;

import Model.Marca;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class InserirMarcaController {
    @FXML
    private Button sair;

    @FXML
    private Button salvar;

    @FXML
    private Button voltar;

    @FXML
    private TextField nomeMarca;

    @FXML
    private TextField sedeMarca;

    @FXML
    private TextField valorMarca;

    @FXML
    void opSalvar(ActionEvent event) throws IOException{

        final Marca marca = new Marca(nomeMarca.getText().toUpperCase(),
                                sedeMarca.getText().toUpperCase(),
                                Double.valueOf(valorMarca.getText().replace("," , ".")));

        final MarcaController c = new MarcaController();

        final boolean t = c.repetido(marca.getNome());

        if(t == false){

            c.inserirMarca(marca);
                    Notifications.create()
                        .position(Pos.CENTER)
                        .title("Boa...")
                        .text("Sucesso ao inserir.... Marca cadastrada com sucesso!!!")
                        .showInformation();

            App.setRoot("/View/TelaMenuMarca");

        }else{

            Notifications.create()
                .position(Pos.CENTER)
                .title("Erro...")
                .text("Erro ao inserir.... Já existe essa marca cadastrada!!!")
                .showInformation();

        }
        
    }

    @FXML
    void opVoltar(ActionEvent event) throws IOException{

        App.setRoot("/View/TelaMenuMarca");

    }

    @FXML
    void opSair(ActionEvent event) {

       Stage janela = (Stage) sair.getScene().getWindow();
       janela.close();

    }

}